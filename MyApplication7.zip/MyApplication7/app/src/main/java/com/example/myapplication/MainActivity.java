package com.example.myapplication;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = (Button)findViewById(R.id.bt_calcular);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText cns = (EditText)findViewById(R.id.edt_consumo);
                EditText c_art = (EditText)findViewById(R.id.edt_couver_artistico);
                EditText dividir = (EditText)findViewById(R.id.edt_dividir);
                EditText txServ = (EditText)findViewById(R.id.edt_servico);
                EditText total = (EditText)findViewById(R.id.edt_conta_total);
                EditText valPes = (EditText)findViewById(R.id.edt_valor_pessoa);

                double cns1 = Double.parseDouble(cns.getText().toString());
                double c_art1 = Double.parseDouble(c_art.getText().toString());
                double dividir1 = Double.parseDouble(dividir.getText().toString());
                double txServ1 = Double.parseDouble(txServ.getText().toString());
                double total1 = Double.parseDouble(total.getText().toString());
                double valPes1 = Double.parseDouble(valPes.getText().toString());

                txServ1 = 10 * (cns1 + c_art1/100);
                valPes1 = cns1 + c_art1 + txServ1 / dividir1;
                total1 = cns1 + c_art1 + txServ1;

                txServ.setText(""+txServ1);
                valPes.setText(""+valPes1);
                total.setText(""+total1);
            }
        });
    }
}


